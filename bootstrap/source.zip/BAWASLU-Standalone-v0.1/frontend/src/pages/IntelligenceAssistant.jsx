import { useState } from 'react';
import { Send } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import AssistantRecords from '@/components/intel/AssistantRecords';
import AssistantAnswer from '@/components/intel/AssistantAnswer';
const starters=[
  'What are the latest validated intelligence records?',
  'What are the main issues in my jurisdiction?',
  'Summarise intelligence from the last 7 days.',
  'What campaign-related issues are being reported?',
  'Which locations appear most frequently?',
  'What are the highest-priority intelligence records?',
  'Show me intelligence related to campaign materials.',
  'What intelligence remains supported by unverified evidence?',
  'Summarise today’s intelligence.'
];
export default function IntelligenceAssistant(){
  const [question,setQuestion]=useState(''),[messages,setMessages]=useState([]),[busy,setBusy]=useState(false),[error,setError]=useState('');
  async function ask(text){const q=text.trim();if(!q||busy)return;setBusy(true);setError('');setQuestion('');setMessages(old=>[...old,{role:'user',text:q}]);try{const previousQuestion=[...messages].reverse().find(m=>m.role==='user')?.text||'';const response=await base44.functions.invoke('intelligenceAssistant',{question:q,previousQuestion});setMessages(old=>[...old,{role:'assistant',text:response.data.answer,records:response.data.records||[]}]);}catch(e){setError(e.response?.data?.error||'Unable to answer right now. Please retry.');setMessages(old=>old.slice(0,-1));setQuestion(q)}finally{setBusy(false)}}
  return <div className="max-w-4xl mx-auto space-y-5"><div><p className="text-xs font-bold uppercase tracking-[.18em] text-[#9a7e49] mb-2">Intelligence / Read-only</p><h1 className="intel-heading">BAWASLU Intelligence Assistant</h1><p className="text-sm font-medium text-[#29445d] mt-2">Ask your intelligence. Trace every answer.</p><p className="text-sm text-[#617789] mt-2">Ask questions about intelligence available within your authorized BAWASLU scope. Answers are grounded in accessible intelligence records and linked to supporting evidence.</p></div><div className="flex justify-end"><button type="button" className="intel-ghost" disabled={busy||!messages.length} onClick={()=>{setMessages([]);setQuestion('');setError('')}}>New conversation</button></div><div className="intel-card p-5 md:p-7 space-y-5" aria-live="polite">{!messages.length&&<div><p className="text-sm font-semibold mb-3">Try asking</p><div className="flex flex-wrap gap-2">{starters.map(s=><button type="button" key={s} disabled={busy} onClick={()=>ask(s)} className="intel-ghost text-left text-xs">{s}</button>)}</div></div>}{messages.map((m,i)=><div key={i} className={m.role==='user'?'flex justify-end':'flex justify-start'}><div className={m.role==='user'?'max-w-[90%] rounded-xl bg-[#153b57] text-white px-4 py-3 text-sm':'w-full rounded-xl bg-[#f5f7fa] border border-[#e4e9ef] p-4 text-sm'}>{m.role==='assistant'?<AssistantAnswer text={m.text}/>:<p className="whitespace-pre-line leading-6">{m.text}</p>}{m.role==='assistant'&&<AssistantRecords records={m.records}/>}</div></div>)}{busy&&<p role="status" className="text-sm text-[#617789]">Reviewing accessible records...</p>}{error&&<p role="alert" className="text-sm text-red-700">{error}</p>}</div><form onSubmit={e=>{e.preventDefault();ask(question)}} className="intel-card p-3 flex gap-2"><input aria-label="Question for BAWASLU Intelligence Assistant" className="intel-input flex-1" maxLength={400} placeholder="Ask about your intelligence records..." value={question} onChange={e=>setQuestion(e.target.value)}/><button className="intel-button" disabled={busy||!question.trim()}><Send size={16}/><span className="hidden sm:inline">Send</span></button></form><p className="text-xs text-[#8192a3]">Read-only · Session history stays in this tab · AI interprets the question, not the evidence.</p></div>;
}